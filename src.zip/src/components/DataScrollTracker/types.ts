export interface DataScrollTrackerProps {
  children: React.ReactNode;
}
