import Script from 'next/script';

export function Scripts() {
  return <></>;
}
