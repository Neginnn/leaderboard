export const defaultMetaTitle = "Negin Test";
export const defaultMetaDescription = "This is the Neegin Test environment";
export const defaultMetaImage =
  "https://fastly.picsum.photos/id/866/200/300.jpg";
