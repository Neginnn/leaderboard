export interface MetaProps {
  title?: string;
  description?: string;
  image?: string;
  noIndex?: boolean;
}
