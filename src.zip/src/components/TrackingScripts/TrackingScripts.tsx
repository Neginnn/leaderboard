// Note: Tracking Scripts Component
export function TrackingScripts() {
  const trackingEnabled = true;

  return <>{trackingEnabled && <></>}</>;
}
