export { initSegment, getAnalytics } from './segment';
